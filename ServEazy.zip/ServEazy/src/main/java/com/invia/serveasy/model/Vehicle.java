package com.invia.serveasy.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "vehicle")
public class Vehicle{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String vehicle_name;

    @NotNull
    private double vehicle_price;

    @NotNull
    private String currency_unit;

    @NotNull
    private String  currency_type;    
    
   @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn( name = "id", nullable = false)
    //@OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
	/*@OneToOne(cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,
            mappedBy = "manufacture_id")*/
    private Manufacture manufacture_id;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getVehicle_name() {
	return vehicle_name;
}

public void setVehicle_name(String vehicle_name) {
	this.vehicle_name = vehicle_name;
}

public double getVehicle_price() {
	return vehicle_price;
}

public void setVehicle_price(double vehicle_price) {
	this.vehicle_price = vehicle_price;
}

public String getCurrency_unit() {
	return currency_unit;
}

public void setCurrency_unit(String currency_unit) {
	this.currency_unit = currency_unit;
}

public String getCurrency_type() {
	return currency_type;
}

public void setCurrency_type(String currency_type) {
	this.currency_type = currency_type;
}

public Manufacture getManufacture_id() {
	return manufacture_id;
}

public void setManufacture_id(Manufacture manufacture_id) {
	this.manufacture_id = manufacture_id;
}

    /*
     * 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Post post;
    
    */

    // Getters and Setters (Omitted for brevity)
   
   
}