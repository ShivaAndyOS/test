package com.invia.serveasy.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.invia.serveasy.exception.ResourceNotFoundException;
import com.invia.serveasy.model.Manufacture;
import com.invia.serveasy.model.Media;
import com.invia.serveasy.model.Vehicle;
import com.invia.serveasy.repository.ManufactureRepository;
import com.invia.serveasy.repository.MediaRepository;
import com.invia.serveasy.repository.VehicleRepository;

@RestController
@RequestMapping("/api")
public class MediaController {

    @Autowired
    MediaRepository repository;
    
    @GetMapping("/media")
    public List<Media>  getAllList(){
    	return repository.findAll();
    }

    @PostMapping("/media")
    public Media create(@Valid @RequestBody Media note) {
        return repository.save(note);
    }
    
    @GetMapping("/media/{id}")
    public Media  getManufactureById(@PathVariable(value = "id") Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("/Media", "id", id));
    }
}
