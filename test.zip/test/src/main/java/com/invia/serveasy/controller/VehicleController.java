package com.invia.serveasy.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.invia.serveasy.exception.ResourceNotFoundException;
import com.invia.serveasy.model.Manufacture;
import com.invia.serveasy.model.Vehicle;
import com.invia.serveasy.repository.ManufactureRepository;
import com.invia.serveasy.repository.VehicleRepository;

@RestController
@RequestMapping("/api")
public class VehicleController {

    @Autowired
    VehicleRepository repository;
    
    @Autowired
    ManufactureRepository mRepository;
    
    @GetMapping("/vehicle")
    public List<Vehicle>  getAllList(){
    	return repository.findAll();
    }
   
    
    @RequestMapping(value="/vehicle", method=RequestMethod.POST)
    public ResponseEntity<?>  delete(@RequestParam("id") int id){
    	Vehicle note = repository.findById(id);
               // .orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));

        repository.delete(note);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/vehicle/{id}")
    public Vehicle create(@PathVariable("id") long id,@Valid @RequestBody Vehicle note) {
    	Manufacture vehicle=mRepository.findById(id);
    	System.out.println("===>"+vehicle.toString());
    	note.setManufacture_id(vehicle);
    	System.out.println("vehicle data: "+note);
        return repository.save(note);
    }
    
    @GetMapping("/vehicle/{id}")
    public Vehicle  getManufactureById(@PathVariable(value = "id") Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Manufacture", "id", id));
    }
}
