package com.invia.serveasy.repository;

import com.invia.serveasy.model.Vehicle;

import javax.websocket.server.PathParam;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
	Vehicle findById(long id);
}
