package com.invia.serveasy.controller;


import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.invia.serveasy.model.Post;
import com.invia.serveasy.repository.PostRepository;
import com.invia.serveasy.exception.ResourceNotFoundException;

public class PostController  {

    @Autowired
    PostRepository postRepository;

   /* @GetMapping("/posts")
    public Page<Post> getAllPosts(@PathParam(value = 1) int post_id, Pageable pageable) {
        return postRepository.findAll(post_id, pageable);
    }*/

    @PostMapping("/posts")
    public Post createPost(@Valid @RequestBody Post post) {
        return postRepository.save(post);
    }

    @PutMapping("/posts/{postId}")
    public Post updatePost(@PathVariable Long postId, @Valid @RequestBody Post postRequest) {
        return postRepository.findById(postId).map(post -> {
            post.setTitle(postRequest.getTitle());
            post.setDescription(postRequest.getDescription());
            post.setContent(postRequest.getContent());
            return postRepository.save(post);
        }) .orElseThrow(() -> new ResourceNotFoundException("Media", "id", postId));
    }


    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId) {
        return postRepository.findById(postId).map(post -> {
            postRepository.delete(post);
            return ResponseEntity.ok().build();
        }) .orElseThrow(() -> new ResourceNotFoundException("Media", "id", postId));
    }

}
