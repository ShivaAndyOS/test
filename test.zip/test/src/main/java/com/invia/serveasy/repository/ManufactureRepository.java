package com.invia.serveasy.repository;

import com.invia.serveasy.model.Manufacture;
import com.invia.serveasy.model.Note;
import com.invia.serveasy.model.Vehicle;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManufactureRepository extends JpaRepository<Manufacture, Long> {
	Manufacture findById(long id);
}
