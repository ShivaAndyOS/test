package com.invia.serveasy.repository;

import java.awt.print.Pageable;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.invia.serveasy.model.Comment;
import com.invia.serveasy.model.Post;

@Repository
public interface  PostRepository  extends JpaRepository<Post, Long> {
    Page<Comment> findByPostId(Long postId, Pageable pageable);
    //Post findByPostId(Long postId);
}
