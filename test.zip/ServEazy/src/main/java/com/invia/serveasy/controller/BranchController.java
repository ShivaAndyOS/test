package com.invia.serveasy.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.invia.serveasy.exception.ResourceNotFoundException;
import com.invia.serveasy.model.Branch;
import com.invia.serveasy.model.Company;
import com.invia.serveasy.model.Manufacture;
import com.invia.serveasy.model.Media;
import com.invia.serveasy.model.Vehicle;
import com.invia.serveasy.repository.BranchRepository;
import com.invia.serveasy.repository.CompanyRepository;
import com.invia.serveasy.repository.ManufactureRepository;
import com.invia.serveasy.repository.MediaRepository;
import com.invia.serveasy.repository.VehicleRepository;

@RestController
@RequestMapping("/api")
public class BranchController {

    @Autowired
    BranchRepository repository;
    
    @GetMapping("/branch")
    public List<Branch>  getAllList(){
    	return repository.findAll();
    }

    @PostMapping("/branch")
    public Branch create(@Valid @RequestBody Branch note) {
        return repository.save(note);
    }
    
    @GetMapping("/branch/{id}")
    public Branch  getManufactureById(@PathVariable(value = "id") Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch", "id", id));
    }
}
